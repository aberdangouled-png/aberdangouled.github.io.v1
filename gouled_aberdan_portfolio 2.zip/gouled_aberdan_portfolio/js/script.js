// GOULED ABERDAN | ICT RESUME WEBSITE | script.js
// One shared file for every page. Each feature checks that its element exists first,
// so the same script can safely load on all five pages.
// Features: 1 theme toggle, 2 typewriter, 3 portfolio lightbox, 4 contact form, 5 back-to-top

(function () {
  'use strict';

  // ---------------------------------------------------------------
  // 1. THEME TOGGLE (light / dark)
  // Uses the saved choice if there is one, otherwise the visitor's
  // system preference. localStorage is wrapped in try/catch because it
  // can be blocked (private windows), and the site must still work.
  // ---------------------------------------------------------------
  var html = document.documentElement;
  var switcher = document.querySelector('#themeSwitch');
  var theme = 'light';

  try {
    theme = localStorage.getItem('ga-theme') ||
      (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  } catch (error) {
    theme = 'light';
  }

  html.setAttribute('data-bs-theme', theme);

  if (switcher) {
    switcher.checked = theme === 'dark';
    switcher.addEventListener('change', function () {
      var next = switcher.checked ? 'dark' : 'light';
      html.setAttribute('data-bs-theme', next);
      try { localStorage.setItem('ga-theme', next); } catch (error) { /* toggle still works */ }
    });
  }

  // ---------------------------------------------------------------
  // 2. HOME PAGE TYPEWRITER
  // Words come from the data-words attribute in index.html.
  // Visitors who prefer reduced motion just see the first word.
  // ---------------------------------------------------------------
  var typingTarget = document.querySelector('.typewrite');

  if (typingTarget) {
    var words = JSON.parse(typingTarget.getAttribute('data-words') || '[]');
    var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var wordIndex = 0;
    var charIndex = 0;
    var deleting = false;

    if (reduceMotion && words.length) {
      typingTarget.textContent = words[0];
      typingTarget.style.animation = 'none';
      typingTarget.style.borderRight = '0';
    } else if (words.length) {
      var typeLoop = function () {
        var word = words[wordIndex];
        charIndex += deleting ? -1 : 1;
        typingTarget.textContent = word.slice(0, charIndex);

        var delay = deleting ? 55 : 95;
        if (!deleting && charIndex === word.length) {
          deleting = true;
          delay = 1400;               // pause on the finished word
        } else if (deleting && charIndex === 0) {
          deleting = false;
          wordIndex = (wordIndex + 1) % words.length;
          delay = 350;
        }
        window.setTimeout(typeLoop, delay);
      };
      typeLoop();
    }
  }

  // ---------------------------------------------------------------
  // 3. PORTFOLIO LIGHTBOX
  // One Bootstrap modal is reused: the clicked card's data-* attributes
  // fill in the title, image and description.
  // ---------------------------------------------------------------
  var modalEl = document.getElementById('projectLightbox');

  if (modalEl) {
    var modalTitle = modalEl.querySelector('.modal-title');
    var modalImage = modalEl.querySelector('.lightbox-image');
    var modalText = modalEl.querySelector('.lightbox-text');

    document.querySelectorAll('[data-project-image]').forEach(function (button) {
      button.addEventListener('click', function () {
        modalTitle.textContent = button.getAttribute('data-project-title') || 'Project preview';
        modalImage.src = button.getAttribute('data-project-image') || '';
        modalImage.alt = button.getAttribute('data-project-alt') || 'Project preview';
        modalText.textContent = button.getAttribute('data-project-text') || '';
      });
    });
  }

  // ---------------------------------------------------------------
  // 4. CONTACT FORM
  // This is a static site with no server, so a valid form opens the
  // visitor's own email app with the message pre-filled (mailto:).
  // ---------------------------------------------------------------
  var form = document.querySelector('.needs-validation');

  if (form) {
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      event.stopPropagation();
      form.classList.add('was-validated');

      var status = form.querySelector('.form-status');

      if (!form.checkValidity()) {
        status.textContent = 'Please complete the highlighted fields, then try again.';
        return;
      }

      var name = form.querySelector('#name').value.trim();
      var email = form.querySelector('#email').value.trim();
      var reason = form.querySelector('#reason').value;
      var message = form.querySelector('#message').value.trim();

      var subject = 'Website enquiry: ' + reason;
      var body = message + '\n\nFrom: ' + name + ' (' + email + ')';

      status.textContent = 'Opening your email app with your message ready to send...';
      window.location.href = 'mailto:aberdangouled@gmail.com' +
        '?subject=' + encodeURIComponent(subject) +
        '&body=' + encodeURIComponent(body);
    });
  }

  // ---------------------------------------------------------------
  // 5. BACK-TO-TOP BUTTON (appears after scrolling down 400px)
  // ---------------------------------------------------------------
  var toTop = document.querySelector('.back-to-top');

  if (toTop) {
    window.addEventListener('scroll', function () {
      toTop.classList.toggle('visible', window.scrollY > 400);
    }, { passive: true });
  }
})();
